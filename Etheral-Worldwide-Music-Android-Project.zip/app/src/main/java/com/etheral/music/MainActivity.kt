package com.etheral.music

import android.content.ComponentName
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.media3.common.MediaItem
import androidx.media3.common.MediaMetadata
import androidx.media3.common.Player
import androidx.media3.session.MediaController
import androidx.media3.session.SessionToken
import coil.compose.AsyncImage
import com.google.common.util.concurrent.ListenableFuture
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URLEncoder
import java.net.URL

private const val API = "https://api.audius.co/v1"
private const val APP_NAME = "etheral_music_android"

private data class Track(
    val id: String,
    val title: String,
    val artist: String,
    val artwork: String?,
    val duration: Int
) {
    val streamUrl: String
        get() = "$API/tracks/${Uri.encode(id)}/stream?app_name=$APP_NAME"
}

private suspend fun searchAudius(query: String): List<Track> = withContext(Dispatchers.IO) {
    val encoded = URLEncoder.encode(query, "UTF-8")
    val url = URL("$API/tracks/search?query=$encoded&limit=30&app_name=$APP_NAME")
    val connection = (url.openConnection() as HttpURLConnection).apply {
        connectTimeout = 12000
        readTimeout = 15000
        requestMethod = "GET"
        setRequestProperty("Accept", "application/json")
    }
    try {
        val body = connection.inputStream.bufferedReader().use { it.readText() }
        val array = JSONObject(body).optJSONArray("data") ?: return@withContext emptyList()
        buildList {
            for (i in 0 until array.length()) {
                val item = array.optJSONObject(i) ?: continue
                val user = item.optJSONObject("user")
                val art = item.optJSONObject("artwork")
                val image = art?.optString("150x150")?.takeIf { it.startsWith("http") }
                    ?: art?.optString("480x480")?.takeIf { it.startsWith("http") }
                val id = item.optString("id")
                if (id.isNotBlank() && id != "null") add(
                    Track(
                        id = id,
                        title = item.optString("title", "Untitled"),
                        artist = user?.optString("name") ?: "Unknown artist",
                        artwork = image,
                        duration = item.optInt("duration", 0)
                    )
                )
            }
        }
    } finally {
        connection.disconnect()
    }
}

private fun timeLabel(seconds: Int): String {
    if (seconds <= 0) return ""
    return "%d:%02d".format(seconds / 60, seconds % 60)
}

class MainActivity : ComponentActivity() {
    private var controllerFuture: ListenableFuture<MediaController>? = null
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val token = SessionToken(this, ComponentName(this, PlayerService::class.java))
        controllerFuture = MediaController.Builder(this, token).buildAsync()
        setContent {
            var controller by remember { mutableStateOf<MediaController?>(null) }
            LaunchedEffect(Unit) {
                controllerFuture?.let { runCatching { controller = it.get() } }
            }
            EtheralApp(controller)
        }
    }
    override fun onDestroy() {
        controllerFuture?.let { MediaController.releaseFuture(it) }
        super.onDestroy()
    }
}

@Composable
private fun EtheralApp(player: MediaController?) {
    val purple = Color(0xFFB99AFF)
    val bg = Color(0xFF050505)
    var query by remember { mutableStateOf("") }
    var results by remember { mutableStateOf<List<Track>>(emptyList()) }
    var loading by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }
    var tab by remember { mutableStateOf("Discover") }
    var current by remember { mutableStateOf<Track?>(null) }
    var isPlaying by remember { mutableStateOf(false) }
    var favorites by remember { mutableStateOf(setOf<String>()) }

    DisposableEffect(player) {
        val listener = object : Player.Listener {
            override fun onIsPlayingChanged(value: Boolean) { isPlaying = value }
        }
        player?.addListener(listener)
        onDispose { player?.removeListener(listener) }
    }

    MaterialTheme(colorScheme = darkColorScheme(
        primary = purple, background = bg, surface = Color(0xFF111111),
        onBackground = Color.White, onSurface = Color.White
    )) {
        Scaffold(
            containerColor = bg,
            bottomBar = {
                NavigationBar(containerColor = Color(0xFF0B0B0B), contentColor = Color.White) {
                    listOf("Discover", "Search", "Liked").forEach { item ->
                        NavigationBarItem(
                            selected = tab == item,
                            onClick = { tab = item },
                            icon = {
                                Icon(when (item) {
                                    "Discover" -> Icons.Default.Explore
                                    "Search" -> Icons.Default.Search
                                    else -> Icons.Default.Favorite
                                }, contentDescription = item)
                            },
                            label = { Text(item) },
                            colors = NavigationBarItemDefaults.colors(
                                selectedIconColor = purple, selectedTextColor = purple,
                                indicatorColor = Color(0xFF211A2B),
                                unselectedIconColor = Color.Gray, unselectedTextColor = Color.Gray
                            )
                        )
                    }
                }
            }
        ) { padding ->
            Column(Modifier.fillMaxSize().padding(padding)) {
                Row(
                    Modifier.fillMaxWidth().padding(horizontal = 22.dp, vertical = 18.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(Modifier.weight(1f)) {
                        Text("ETHERAL", color = purple, fontSize = 12.sp, fontWeight = FontWeight.Black, letterSpacing = 5.sp)
                        Text(
                            when (tab) { "Liked" -> "Your favourites"; "Search" -> "Find your sound"; else -> "Music without borders" },
                            fontSize = 25.sp, fontWeight = FontWeight.Bold
                        )
                    }
                    Icon(Icons.Default.GraphicEq, null, tint = purple, modifier = Modifier.size(28.dp))
                }

                if (tab != "Liked") {
                    Row(
                        Modifier.fillMaxWidth().padding(horizontal = 18.dp)
                            .background(Color(0xFF171717), RoundedCornerShape(16.dp))
                            .padding(horizontal = 14.dp, vertical = 14.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(Icons.Default.Search, null, tint = Color.Gray)
                        Spacer(Modifier.width(10.dp))
                        BasicTextField(
                            value = query, onValueChange = { query = it },
                            modifier = Modifier.weight(1f),
                            singleLine = true,
                            textStyle = androidx.compose.ui.text.TextStyle(color = Color.White, fontSize = 15.sp),
                            decorationBox = { inner ->
                                if (query.isEmpty()) Text("Songs, artists, genres...", color = Color.Gray)
                                inner()
                            }
                        )
                        IconButton(
                            onClick = {
                                if (query.isNotBlank()) {
                                    loading = true; error = null
                                    // Search is launched by the composable coroutine below.
                                }
                            }
                        ) { Icon(Icons.Default.ArrowForward, "Search", tint = purple) }
                    }
                    LaunchedEffect(query, tab) {
                        if (tab == "Discover" && query.isBlank() && results.isEmpty()) {
                            loading = true
                            try { results = searchAudius("trending"); error = null }
                            catch (e: Exception) { error = "Couldn't load music. Check your connection and try again." }
                            loading = false
                        }
                    }
                    val scope = rememberCoroutineScope()
                    LaunchedEffect(Unit) { }
                    Row(Modifier.fillMaxWidth().padding(horizontal = 22.dp, vertical = 12.dp), verticalAlignment = Alignment.CenterVertically) {
                        Text(if (query.isBlank()) "Trending worldwide" else "Search results", fontSize = 18.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                        TextButton(onClick = {
                            if (query.isNotBlank()) {
                                loading = true; error = null
                                // handled in the effect below
                            }
                        }) { Text("Explore", color = purple) }
                    }
                    LaunchedEffect(query, tab) {
                        if (query.isNotBlank() && tab == "Search") {
                            loading = true; error = null
                            try { results = searchAudius(query) }
                            catch (e: Exception) { error = "Search failed. Please try again." }
                            loading = false
                        }
                    }
                } else {
                    Text("Liked tracks", Modifier.padding(horizontal = 22.dp, vertical = 12.dp), fontSize = 18.sp, fontWeight = FontWeight.Bold)
                }

                val shown = if (tab == "Liked") results.filter { it.id in favorites } else results
                when {
                    loading -> Box(Modifier.fillMaxWidth().weight(1f), contentAlignment = Alignment.Center) {
                        CircularProgressIndicator(color = purple)
                    }
                    error != null -> Box(Modifier.fillMaxWidth().weight(1f).padding(24.dp), contentAlignment = Alignment.Center) {
                        Text(error!!, color = Color.LightGray)
                    }
                    shown.isEmpty() -> Box(Modifier.fillMaxWidth().weight(1f).padding(24.dp), contentAlignment = Alignment.Center) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Icon(Icons.Default.MusicOff, null, tint = Color.Gray, modifier = Modifier.size(38.dp))
                            Spacer(Modifier.height(10.dp))
                            Text(if (tab == "Liked") "No liked tracks yet" else "Search for an artist or song", color = Color.Gray)
                        }
                    }
                    else -> LazyColumn(
                        modifier = Modifier.weight(1f),
                        contentPadding = PaddingValues(start = 18.dp, end = 18.dp, bottom = 14.dp),
                        verticalArrangement = Arrangement.spacedBy(5.dp)
                    ) {
                        items(shown, key = { it.id }) { track ->
                            Row(
                                Modifier.fillMaxWidth().clickable {
                                    current = track
                                    val item = MediaItem.Builder().setUri(track.streamUrl)
                                        .setMediaMetadata(MediaMetadata.Builder().setTitle(track.title).setArtist(track.artist).build()).build()
                                    player?.setMediaItem(item); player?.prepare(); player?.play()
                                }.padding(vertical = 7.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                AsyncImage(
                                    model = track.artwork, contentDescription = "Album art",
                                    modifier = Modifier.size(54.dp).background(Color(0xFF191919), RoundedCornerShape(10.dp))
                                )
                                Column(Modifier.weight(1f).padding(horizontal = 12.dp)) {
                                    Text(track.title, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                    Text(track.artist, color = Color.Gray, fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                }
                                Text(timeLabel(track.duration), color = Color.Gray, fontSize = 11.sp)
                                IconButton(onClick = { favorites = if (track.id in favorites) favorites - track.id else favorites + track.id }) {
                                    Icon(if (track.id in favorites) Icons.Default.Favorite else Icons.Default.FavoriteBorder,
                                        "Like track", tint = if (track.id in favorites) purple else Color.Gray)
                                }
                            }
                        }
                    }
                }

                current?.let { track ->
                    Row(
                        Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 8.dp)
                            .background(Color(0xFF19151F), RoundedCornerShape(15.dp)).padding(10.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        AsyncImage(track.artwork, null, Modifier.size(43.dp).background(Color.DarkGray, RoundedCornerShape(8.dp)))
                        Column(Modifier.weight(1f).padding(horizontal = 10.dp)) {
                            Text(track.title, maxLines = 1, overflow = TextOverflow.Ellipsis, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                            Text(track.artist, color = Color.Gray, fontSize = 11.sp)
                        }
                        IconButton(onClick = { if (player?.isPlaying == true) player.pause() else player?.play() }) {
                            Icon(if (isPlaying) Icons.Default.Pause else Icons.Default.PlayArrow, "Play or pause", tint = purple)
                        }
                    }
                }
            }
        }
    }
}
